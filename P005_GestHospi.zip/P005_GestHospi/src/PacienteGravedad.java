public class PacienteGravedad extends Paciente
{
  
    private TipoGravedad gravedad;

    public PacienteGravedad(String nombre, TipoGravedad gravedad)
    {
        super(nombre);
       this.gravedad = gravedad;
       
    }

    public TipoGravedad getGravedad() {
    	return gravedad;
    }
    
    
    public String toString()
    {
       // Completar
        return super.toString() + ":" + gravedad;
    }
}
