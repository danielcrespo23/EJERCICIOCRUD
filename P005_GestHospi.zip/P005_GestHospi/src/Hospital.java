public class Hospital
{
    private Paciente tpacientes[]; // Al inicio todas las posiciones son igual a null
    private int contadorpacientes;

    public Hospital(int numpacientes)
    {
        tpacientes = new Paciente[numpacientes];
        contadorpacientes = 0;
    }

    // Ingreso de un paciente al hospital, devuelve false si no cabe
    public boolean ingreso(Paciente p)
    {
    	if (contadorpacientes < tpacientes.length) {
    		tpacientes[contadorpacientes] = p;
    		contadorpacientes++;
    		return true;
    	} else {
        return false;
    	}
    }
    // Alta del paciente - se borra de la tabla, su posición se pone a null
    // Devuelve false si no se encuentra
    public boolean alta ( int id_paciente){
   

    	boolean encontrado = false;
    	for (int i = 0; i < contadorpacientes ; i++) {
    		if ( tpacientes[i].getId() == id_paciente) {
    		 encontrado = true;
    		 // Lo eliminamos y desplazo
    		 for (int j = i; j < contadorpacientes-1; j++) {
    			 tpacientes[i] = tpacientes[j+1];
    		 }
    		 contadorpacientes--;
    			break;
    		} 
    	}
 
      return encontrado;   
    }    
    
    // Devuelve el paciente con el identidador indicado o null si no existe
    public Paciente buscar(int id){
    	Paciente p = null;
    	for (int i = 0; i < contadorpacientes ; i++) {
    		if ( tpacientes[i].getId() == id) {
    		 p = tpacientes[i];
    		 break;
    		}
    		}
    	return p;
    }
    
    // Imprime por consola la lista ORDENADO por NOMBRE de pacientes ***

    public void listapacientes (){
    	System.out.println("Lista de pacientes");
    	for (int i = 0 ; i <  contadorpacientes; i++) {
    	System.out.println(tpacientes[i]);
    	}
     
    }    
       
    // Devuelve el mas grave o el caso de paciente con la misma gravedad el
    // que su identificador sea mas bajo.
    public Paciente pacienteMasUrgente(){
    	
    	PacienteGravedad pgmax = null;
    	
    		for (int i =0; i< contadorpacientes; i++) {
    			if (tpacientes[i] instanceof PacienteGravedad) {
    				PacienteGravedad p =  (PacienteGravedad) tpacientes[i];
    				//Si no tengo ninguno, es paciente el que mas grave por ahora
    				if (pgmax == null) {
    					pgmax =p;
    					
    				} else {
    					if (pgmax.getGravedad().ordinal() > p.getGravedad().ordinal() ) {
    						pgmax = p;
    					} else {
    						if ( pgmax.getGravedad().ordinal() == p.getGravedad().ordinal() ) {
    							if (pgmax.getId() > p.getId() ) {
    								pgmax = p;
    							}
    						}
    					}
    				}
    			}
    			
    		}
    	
    	
    	if (contadorpacientes > 0) {
        return tpacientes[0];
    	} else {
    return null;  
        
    } 
    	}
    
}
