// Clase de tipo enumerado
public enum TipoGravedad
{
    MUY_GRAVE,GRAVE,MENOS_GRAVE;
}

