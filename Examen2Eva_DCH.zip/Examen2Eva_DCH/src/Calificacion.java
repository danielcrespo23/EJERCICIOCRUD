
public enum Calificacion {
	MAL, REGULAR, NORMAL, BIEN, EXCELENTE;
}
